**Morpho-phenotypic evaluation of algarrobo *(Neltuma pallida)* for the identification of superior individuals in dry forest ecosystems**

Sebastian Casas-Niño^1,2\*^; Juan Rodrigo Baselly-Villanueva^4^; Evelin Judith Salazar-Hinostroza^4^; Sheyla Yanett Chumbimune-Vivanco^4^; William Naurai^5^; Nery Tirabante Terrones^6^; Max Ramirez Rojas^1^; Flavio Lozano-Isla^1,7\*^.

*^1^ Dirección de Supervisión y Monitoreo en las Estaciones Experimentales - Estación Experimental Agraria El Chira, Instituto Nacional de Innovación Agraria (INIA), Piura 20120, Perú.*

*^2^ Universidad Nacional Agraria La Molina (UNALM), Lima, Perú.*

*^3^ Estación Experimental Agraria San Roque, Instituto Nacional de Innovación Agraria (INIA), 16000, Calle San Roque 209, San Juan Bautista, Maynas, Loreto, Perú.*

*^4^ Dirección de Investigación y Desarrollo Tecnológico, Instituto Nacional de Innovación Agraria (INIA). Lima. Perú.*

*^5^ Dirección de Estudios e Investigación, Servicio Nacional Forestal y de Fauna Silvestre. Lima, Perú.*

*^6^ Universidade Estadual de Campinas, Caixa Postal 6109, 13083-970 Campinas (SP).*

*^7^ Facultad de Ingeniería y Ciencias Agrarias, Universidad Nacional Toribio Rodríguez de Mendoza de Amazonas (UNTRM), Amazonas 01001, Perú.*

* ^\*^ *Corresponding author: [20140231@lamolina.edu.pe](mailto:20140231@lamolina.edu.pe); [flavio.lozano@untrm.edu.pe](mailto:flavio.lozano@untrm.edu.pe) 

ORCID IDs




| **Author**                           | **ORCID**                            | **email**                             |
|--------------------------------------|--------------------------------------|---------------------------------------|
| **Sebastian Casas-Niño**             | 0000-0002-6576-8761                  | 20140231@lamolina.edu.pe              |
| **Juan Rodrigo Baselly-Villanueva**  | 0000-0001-7795-7925                  | jbaselly@inia.gob.pe                  |
| **Evelin Judith Salazar Hinostroza** | 0000-0002-8878-430X                  | esalazar@inia.gob.pe                  |
| **Sheyla Yanett Chumbimune Vivanco** | 0000-0002-2485-0988                  | 20081043@lamolina.edu.pe              |
| **William Nauray**                   | 0000-0003-2114-1518                  | wnauray@serfor.gob.pe                 |
| **Nery Tirabante Terrones**          | 0000-0002-0634-1522                  | nery@lgf.ib.unicamp.br                |
| **Max Ramirez Rojas**                | 0000-0003-3322-0838                  | proyectochira@inia.gob.pe             |
| **Flavio Lozano-Isla**               | 0000-0002-0714-669X                  | flavio.lozano@untrm.edu.pe            |






**ABSTRACT**

*Neltuma pallida*, a keystone species of the dry forest, is currently under severe threat, underscoring the urgent need for its conservation and genetic improvement. This study aimed to identify superior ("plus") trees of algarrobo in Piura and Tumbes through detailed morpho-phenotypic characterization. A stratified random sampling design was implemented, establishing forest plots to evaluate individual trees. Dendrometric and phenotypic traits were recorded, complemented by physiographic, climatic, and edaphic data obtained through soil sampling and geographic information systems. Individuals were classified as plus trees when they displayed outstanding attributes without unfavorable traits. The results revealed a high degree of morphological variability among populations, with superior individuals identified in height, diameter, stem form, and fruit production. Differences in soil fertility exerted significant influence on phenotypic expression. Heritability coefficients were estimated for key traits, allowing the identification of those under greater genetic control and with higher potential response to selection. As an outcome, elite trees were selected and incorporated into a germplasm bank to support genetic improvement programs aimed at ecological restoration and long-term conservation of algarrobo in the Peruvian dry forest. This work provides a foundation for sustainable management strategies grounded in local genetic variability and agroecological knowledge of the ecosystem.

**Keywords:** Plus trees; dry forest; morphological characterization; genetic improvement; phenotypic variability.

# **INTRODUCTION**

*Neltuma pallida,* commonly known as algarrobo, belongs to the genus *Neltuma,* previously classified within *Prosopis* [[1]](https://www.zotero.org/google-docs/?sVhDD3). It is recognized as a valuable forest resource in arid and semi-arid regions [[2]](https://www.zotero.org/google-docs/?ze3RUa) due to its ability to fix atmospheric nitrogen in soils [[3]](https://www.zotero.org/google-docs/?BSHpmY), its longevity, and its durable hardwood of high economic value [[4]](https://www.zotero.org/google-docs/?4PIqla). From an ecological perspective, algarrobo enhances soil fertility and moisture retention, moderates extreme conditions by creating microclimates beneath its canopy [[5]](https://www.zotero.org/google-docs/?J3wyg3), and contributes to the stabilization of fragile desert ecosystems through processes of desalination and microclimatic amelioration [[4]](https://www.zotero.org/google-docs/?4Cb3Ni). In addition, the species plays a role in climate change mitigation through atmospheric carbon sequestration [[6]](https://www.zotero.org/google-docs/?s35wXZ).  

Despite these multiple benefits, algarrobo is considered one of the most threatened genetic resources in South America [[7]](https://www.zotero.org/google-docs/?IZ2K0J). Agricultural expansion, urbanization, and the rise of agroindustrial crops have transformed extensive areas of tropical dry forest [[8]](https://www.zotero.org/google-docs/?e4JL0M), leading to biodiversity loss and ecosystem service decline. In northern Peru, the regions of Piura, Tumbes, Lambayeque, and La Libertad have been especially impacted by deforestation and land-use change [[9]](https://www.zotero.org/google-docs/?ifEmws). Beyond anthropogenic pressures, *N. pallida* populations have also been severely affected by biotic agents. More than 130 insect species have been associated with algarrobo [[10–12]](https://www.zotero.org/google-docs/?afhpPz), among which Enallodiplosis discordis Gagné 1994 is particularly damaging. In its larval stage, this gall midge feeds on leaflets and has been identified as the principal cause of widespread dieback in algarrobo populations [[13]](https://www.zotero.org/google-docs/?gwLnC7).

Given this scenario, monitoring and conservation actions have become imperative [[9]](https://www.zotero.org/google-docs/?uSaVy5), especially since algarrobo has been declared a priority species for research, conservation, and protection by the Peruvian government [[14]](https://www.zotero.org/google-docs/?cteFFW). In this context, genetic and morphological characterization studies are critical, as they allow for the precise distinction of species or local ecotypes and the design of conservation strategies focused on populations with higher adaptive value or greater risk of extinction [[15]](https://www.zotero.org/google-docs/?NNCali). Achieving adequate characterization requires the evaluation of both quantitative and qualitative attributes. Beseega [[16]](https://www.zotero.org/google-docs/?q0nALL) emphasized that individual selection has major implications for genetic resource management and that adaptive phenotypic traits, as well as population origin, should be carefully considered before initiating any selection program. In this regard, phenotypic evaluation is a key step in identifying plus trees [[17]](https://www.zotero.org/google-docs/?Pw8N7u) - individuals with superior phenotypes in one or more economically important traits that may serve as progenitors in genetic improvement and conservation programs [[18–20]](https://www.zotero.org/google-docs/?rxo4EC). In general, traits selected for breeding should (a) exhibit strong genetic control, (b) display high genetic variation, and (c) preferably be easy to measure [[21]](https://www.zotero.org/google-docs/?an9FHE).

The effectiveness of phenotypic characterization and plus tree selection is supported by numerous studies, where phenotypically outstanding trees for one or more economically valuable traits [[19]](https://www.zotero.org/google-docs/?o59rNV) have been successfully used for both conservation and genetic improvement [[22,23]](https://www.zotero.org/google-docs/?Y9hnw7). Heritability is a population - and site - dependent parameter, with estimates varying according to the families included in the assessment, tree age, and the testing environment. This parameter expresses the proportion of variance attributable to genetic transmission from parents to offspring, with values ranging from 0 to 1 [[24]](https://www.zotero.org/google-docs/?br1dl9). For *Neltuma chilensis*, Chequer  [[25]](https://www.zotero.org/google-docs/?4LSZd3) reported moderate heritability for traits such as biomass (h² = 0.28) and spine length (h² = 0.22), emphasizing the importance of considering both provenance and intrafamily variability to maximize genetic gain. Complementary work by López [[26]](https://www.zotero.org/google-docs/?4NQSxB) on *Neltuma alba* under drought stress demonstrated the relevance of functional intraspecific diversity and local adaptation, identifying distinct physiological strategies of drought tolerance linked to leaf morphological traits and genetic variation. These findings reinforce the need to prioritize provenances adapted to changing environmental conditions. Likewise, in species such as *Swietenia macrophylla* [[27]](https://www.zotero.org/google-docs/?rQmTOY) and *Cedrela odorata* [[28]](https://www.zotero.org/google-docs/?SrgJgv), heritability estimates have been used to prioritize genotypes of high genetic value.

Despite its ecological and productive significance, *Neltuma pallida* ([Humb.](http://www.wikidata.org/entity/Q6694) & [Bonpl.](http://www.wikidata.org/entity/Q405702) ex [Willd.](http://www.wikidata.org/entity/Q76353)) Hughes & G.P. Lewis [[1]](https://www.zotero.org/google-docs/?N9I7ya) still lacks integrated studies addressing phenotypic characterization, local adaptation, and plus tree selection in natural populations. To address this gap, the present study aims to characterize algarrobo (*Neltuma pallida*) in populations from Piura and Tumbes, through the evaluation of phenotypic traits, edaphoclimatic conditions, and heritability estimates, with the objective of identifying plus trees with potential for inclusion in future genetic improvement and conservation programs.

# **MATERIALS AND METHODS**

## Study Area

Qualitative and quantitative evaluations of *Neltuma pallida* were conducted across 13 localities in the departments of Piura and Tumbes, northwestern Peru ([Figure 1](?tab=t.ecc2pbe3h01k#bookmark=id.evuenkh5s3p9)). In Tumbes, sampling was carried out in the districts of Zorritos (Contralmirante Villar Province), San Jacinto, and Corrales (Tumbes Province). In Piura, the evaluated districts included Marcavelica and Sullana (Sullana Province), La Matanza and Chulucanas (Morropón Province), and Veintiséis de Octubre (Piura Province).

Both departments are located within the tropical dry forest ecoregion, the natural habitat of *N. pallida.* Piura lies between 4°05′ and 6°22′ S latitude and 79°00′ and 81°07′ W longitude. In the study sites of this department, the average maximum temperature reaches 38.1 °C, while the mean minimum temperature is 15.7 °C. Rainfall is seasonal and scarce, with an annual average of 226.7 mm [[29]](https://www.zotero.org/google-docs/?KhVgKK). Tumbes is situated further north, between 3°22′56.81″ and 4°19′3.48″ S latitude and 80°2′46.90″ and 80°7′37.43″ W longitude. Study sites in this region recorded an average maximum temperature of 37.5 °C and a mean minimum of 17.7 °C. As in Piura, rainfall is seasonal, but with higher accumulation, reaching an annual mean of 324.5 mm [[29]](https://www.zotero.org/google-docs/?U2rfpq).



![Geographic distribution of the 13 study sites where *Neltuma pallida* was evaluated in Piura and Tumbes, northwestern Peru.](img_0.jpg){#fig:id.evuenkh5s3p9}

## Tree sampling methodology

A stratified random sampling design was employed, establishing plots in each study locality that exhibited relatively homogeneous habitat conditions. Within these areas, sampling units were randomly selected, with priority given to zones of higher individual density and canopy cover. Each sampling unit consisted of a 0.5 ha (5,000 m²) forest plot, the recommended area for forest inventories in dry forests of the Peruvian coastal region [[30]](https://www.zotero.org/google-docs/?KArP5k). Plots were established with dimensions of 250 m × 20 m, in accordance with technical guidelines. Within each plot, 10 subplots of 50 m × 10 m were delineated, where all individuals with a diameter at breast height (DBH) ≥ 10 cm were recorded [[31]](https://www.zotero.org/google-docs/?lQRBs8). The assessment included both adult trees and saplings, with their principal morphological and phenotypic traits documented.

## Edaphoclimatic data collection

Soil variables were collected directly in the field. Prior to soil sampling, an exploratory survey was conducted in each study area to identify homogeneous zones in terms of relief, surface color, texture, and land-use type. Based on this preliminary characterization, a random sampling design was applied following a zigzag pattern. At each sampling point (every 15–30 steps), a subsample was extracted with a shovel at a uniform depth of 20–30 cm. For each hectare, between 20 and 30 subsamples were collected and deposited in a clean plastic bucket, mixed thoroughly, and homogenized to form a composite sample [[32]](https://www.zotero.org/google-docs/?hRJoFD). The mixture was subsequently quartered until an approximate volume of 1 kg was obtained. During this process, visible residues of fresh organic matter, stones, and gravel were removed. The final sample was stored in a double clean plastic bag, properly labeled with essential information (identification code, geographic location, sampling date) and hermetically sealed. Samples were then transported to the laboratory for subsequent physicochemical analysis.

Climatic variables were obtained from NASA’s Prediction Of Worldwide Energy Resources [[29]](https://www.zotero.org/google-docs/?1qz6ks) database, accessed on 22 July 2025. The geographic centroid of each locality was used as a reference point for data extraction, considering the period 2015–2024 for analysis. Physiographic variables were derived from Geographic Information Systems (GIS): slope and elevation were extracted from a Digital Elevation Model (DEM) with a spatial resolution of 12.5 m, while distance to water bodies was estimated using Euclidean distance from Peru’s official hydrographic network.



: Description of the edaphoclimatic characteristics of the study localities distributed across the departments of Piura and Tumbes. CaCO₃: calcium carbonates; EC: electrical conductivity; P: phosphorus; OM: organic matter; N: nitrogen; K: potassium; pH: hydrogen potential; CS: incoming solar radiation; pp: precipitation; RH: relative humidity; Tmean: mean temperature; WS: wind speed; Tmax: maximum temperature; Tmin: minimum temperature; SLI: elevation above sea level; Slope: slope; DW: Euclidean distance to water bodies. {#tbl:id.88irmae95cuw}




|                | **Variable**   | **Minimum**    | **Maximum**    | **Mean**       | **Deviation**   |
|----------------|----------------|----------------|----------------|----------------|-----------------|
| Edaphic        | CaCO~3~  (%)   | 0.09           | 2.1            | 1.03           | 0.7             |
|                | EC (dS/m)      | 0.03           | 7.69           | 0.78           | 2.08            |
|                | P (ppm)        | 8.42           | 250.1          | 84.88          | 94.85           |
|                | OM (%)         | 0.19           | 6.7            | 2.29           | 2.31            |
|                | N (%)          | 0.03           | 0.2            | 0.09           | 0.04            |
|                | K (ppm)        | 11.1           | 1321.13        | 415            | 396.57          |
|                | pH             | 5.59           | 8.68           | 7.37           | 1.01            |
| Climatic       | CS (MJ/m²/day) | 11.2           | 11.4           | 11.32          | 0.09            |
|                | pp (mm/day)    | 190.8          | 495.6          | 264.31         | 86.83           |
|                | RH (%)         | 60.4           | 73.1           | 62.59          | 3.33            |
|                | Tmean (°C)     | 22.9           | 26.3           | 25.25          | 0.97            |
|                | WS (m/s)       | 2.1            | 4              | 3.18           | 0.66            |
|                | Tmax (°C)      | 31.4           | 39.3           | 37.85          | 2.15            |
|                | Tmin (°C)      | 14             | 20.4           | 16.45          | 1.49            |
| Physiographic  | SLI (m)        | 5              | 180            | 71.08          | 50.16           |
|                | Slope (%)      | 0.33           | 5.13           | 2.61           | 1.49            |
|                | DW (m)         | 14.17          | 2817.37        | 751.48         | 894.24          |


## Phenotypic evaluation

Each evaluated tree was assigned a sequential identification number based on the order of registration within the plot. This number was recorded in the field form and served as a unique code for all subsequent measurements. Following an adaptation of the criteria established by Alban [[33]](https://www.zotero.org/google-docs/?JXmQV4), data were collected on dendrometric and phenotypic variables. Tree heights were measured using hypsometers, while DBH and crown diameters were measured with metric tapes.

The recorded variables included: total tree height (m); height of the first branching (m); diameter at breast height (DBH, cm), measured at 1.30 m above ground level with adjustments for tree morphology (e.g., bifurcations, sloping terrain); and crown diameter (m), calculated from the average of the longest and shortest crown diameters. In addition, qualitative traits were evaluated, including tree form, stem quality, branching pattern, fruit production, fruit quality, and foliage quality.



: Qualitative evaluation scale of morphological and functional traits in *Neltuma pallida* individuals, following the criteria of Alban [[33]](https://www.zotero.org/google-docs/?lxucT9). {#tbl:id.j88j0bwdsgmh}




| **Variable**                                  | **Evaluation criteria**                        |
|-----------------------------------------------|------------------------------------------------|
| Tree form                                     | 1 = Multi-stemmed (<1.2 m) with branches >30°  |
|                                               | 2 = Intermediate                               |
|                                               | 3 = Single stem (<1.2 m) with branches ≤30°    |
| Trunk quality                                 | 1 = Defective                                  |
|                                               | 2 = Fair with defects                          |
|                                               | 3 = No defects or only minor defects           |
| Forking                                       | 1 = Below DBH                                  |
|                                               | 2 = At DBH                                     |
|                                               | 3 = No branching                               |
| Fruit production                              | 0 = No fruits                                  |
|                                               | 1 = Up to 25% of the branches                  |
|                                               | 2 = Up to 50%                                  |
|                                               | 3 = Up to 75%                                  |
|                                               | 4 = Up to 100%                                 |
| Fruit quality                                 | 0 = Very bitter                                |
|                                               | 1 = Bitter                                     |
|                                               | 2 = Sweet                                      |
|                                               | 3 = Very sweet                                 |
| Foliage quality                               | 1 = Foliage on up to 1/3 of the branches       |
|                                               | 2 = Up to 2/3 of the branches                  |
|                                               | 3 = Full foliage on all branches               |




## Plus tree selection

The selection of plus trees was based on an integrative approach that considered both quantitative and qualitative attributes. A scoring system was established using rank ranges for each type of variable in order to identify individuals with outstanding phenotypic traits. For qualitative variables, individuals that scored greater than or equal to three on the evaluation scale ([Table 2](?tab=t.ecc2pbe3h01k#bookmark=id.j88j0bwdsgmh)) were selected. For quantitative variables, individuals with the highest values were prioritized ([Table 3](?tab=t.ecc2pbe3h01k#bookmark=id.pte78kicwqlx)). Any tree that exhibited at least one unfavorable characteristic (scores ≤ 1) was excluded from the selection process, as it did not meet the minimum criteria for consideration as superior genetic material.



: Scoring ranges for quantitative variables used in the selection of *Neltuma pallida* plus tree candidates. {#tbl:id.pte78kicwqlx}




| **Variable**                         | **Score Ranges**                      |
|--------------------------------------|---------------------------------------|
| Diameter at breast height (DBH) (cm) | 1 = 10–35 cm                          |
|                                      | 2 = 36–60 cm                          |
|                                      | 3 = 61–85 cm                          |
|                                      | 4 = >86 cm                            |
| Total height (m)                     | 1 = 4.0–9.0 m                         |
|                                      | 2 = 9.1–14.0 m                        |
|                                      | 3 = 14.1–19.0 m                       |
|                                      | 4 = 19.1–24.0 m                       |
|                                      | 5 = 24.1–29.0 m                       |
| Branch height  (m)                   | 1 = 0–2.0 m                           |
|                                      | 2 = 2.1–4.0 m                         |
|                                      | 3 = 4.1–6.0 m                         |
|                                      | 4 = 6.1–8.0 m                         |
|                                      | 5 = >8.1 m                            |
| Crown diameter (m)                   | 1 = 0–5.0 m                           |
|                                      | 2 = 6.0–10.0 m                        |
|                                      | 3 = 11.0–15.0 m                       |
|                                      | 4 = 16.0–20.0 m                       |
|                                      | 5 = >21 m                             |




## Heritability

Broad-sense heritability (H²) and the variance components of phenotypic variation were estimated for *Neltuma pallida* populations. A linear mixed model was implemented to estimate variance components following the approach proposed by Cullis [[34]](https://www.zotero.org/google-docs/?LiwDLd), which is appropriate for hierarchical structures and unbalanced data [[35]](https://www.zotero.org/google-docs/?LcACAD). The model included province and locality as fixed effects, while random effects accounted for the general intercept, province, and nested localities. Heritability was calculated using the following fixed- and random-effects models:

Fixed model: $$y_{ijk} = \mu + \text{locality}_j + \text{province}_k$$

Random model: $$y_{ijk} = \mu + (1 | \text{province}_k) + (1 | \text{locality}_j) + \varepsilon_{ijk}$$

where $y_{ijk}$ represents the observation of trait $i$ in locality $j$ and province $k$, and $\varepsilon_{ijk}$ is the residual error term. The number of replicates was set at eight, corresponding to the maximum number of evaluated localities.

In addition to H², the variance components were calculated for genetic variance (V.g), environmental or error variance (V.e) and total phenotypic variance (V.p). Based on these values, a relative variance ratio index, hereafter referred to as \`Ratio\`, was constructed and expressed as:

$$\text{Ratio}=V_g:V_p:V_e\quad\text{(normalized with respect to}V_g)$$

## Data processing and statistical analysis

All statistical analyses and graphical outputs were conducted in R software, version 4.5.0 [[36]](https://www.zotero.org/google-docs/?hSnyZO). The coding workflow, data analysis, and computational environment were implemented in Quarto [[37]](https://www.zotero.org/google-docs/?pfzQzo), an integrated system for scientific writing and data analysis (Supplementary Material 1).

For multivariate analyses, data were standardized (mean = 0; variance = 1) to homogenize variable scales and reduce bias from differing units of measurement [[38]](https://www.zotero.org/google-docs/?5WfpZ2). Principal component analysis (PCA) was employed to explore multivariate relationships among edaphoclimatic variables and localities, as well as among phenotypic variables, localities, and individuals. PCA was performed using the packages *FactoMineR* [[39]](https://www.zotero.org/google-docs/?wX33Rl) and *factoextra* [[40]](https://www.zotero.org/google-docs/?oQ1SaE). 

Phenotypic diversity of qualitative variables was quantified using the Shannon–Weaver diversity index (H′), implemented with the *vegan* package [[41]](https://www.zotero.org/google-docs/?ky0HhR). Quantitative variables were analyzed using one-way analysis of variance (ANOVA), and group mean comparisons were conducted with Tukey’s HSD test at a significance level of α = 0.05, implemented through the *emmeans* package  **[[42]](https://www.zotero.org/google-docs/?ZOglDq). To identify patterns in the multivariate data and visualize similarity structures among localities, hierarchical heatmaps were generated using the *heatmaply* package  **[[43]](https://www.zotero.org/google-docs/?qcXj79). Prior to visualization, data were column-normalized, and hierarchical dendrograms were constructed using Euclidean distance matrices.

Genetic parameters and broad-sense heritability (H²) were calculated using the *H2cal()* function implemented in the *inti* package [[44]](https://www.zotero.org/google-docs/?SzeVgW), which integrates fixed and random effects through the *lme4* package [[45]](https://www.zotero.org/google-docs/?Wp6as7). Outlier removal was performed (*outliers.rm* = TRUE), and diagnostic plots were generated (*plot\_diag* = TRUE). For plus tree selection, Best Linear Unbiased Estimators (BLUEs) were computed.

# RESULTS

## Edaphoclimatic characterization

Principal component analysis (PCA) revealed that the first two components jointly explained 59.40% of the total system variability, with 39.90% attributed to the first component (Dim 1) and 19.50% to the second component (Dim 2). In Dim 1, the variables with the highest contributions were pH (12.40%), CaCO₃ (11.22%), and P (11.12%). In Dim 2, the main contributors were Tmax (23.67%), precipitation (pp, 21.54%), and relative humidity (RH, 20.37%).

On the factorial plane, the soil variables N, P, K, and OM showed a positive association and were projected onto the positive quadrant of Dim 1. In contrast, pH and CaCO₃ were oriented in the opposite direction, indicating a negative relationship with the nutrient-related variables. Among the climatic variables, Tmin, pp, and RH shared a common orientation, whereas incoming solar radiation (CS) was positioned in the opposite region. Physiographic variables did not display a clear pattern of association.

The spatial distribution of localities reflected distinct environmental gradients. Monte Azul and Chanchape clustered in the region associated with higher contents of N, P, K, and OM. Conversely, Rica Playa, Pedregal, and Marginal forest were located near the vectors of pH and CaCO₃, suggesting soils with greater alkalinity and carbonate content. Along the climatic gradient, Rica Playa, Pedregal, and Marginal forest were associated with higher values of precipitation (pp), Tmax, Tmin, and Tmean. Relative humidity (RH) was lowest in Rica Playa, Pedregal, and Marginal forest, while Monte Azul and Chanchape displayed intermediate values. Incoming solar radiation (CS) was higher in Monte Azul and Chanchape but lower in Rica Playa, Pedregal, and Marginal forest.

Regarding physiographic characteristics, Pedregal, KM 190, and Fundo Valdez were located closer to water bodies (DW), whereas Kurt Beer, Chanchape, and SENASA were situated at greater distances. The highest elevations (SLI) were recorded at CC Ignacio Távara, KM 190, and Monte Azul, in contrast to Pedregal and INIA, which were positioned at lower elevations.

![Principal component analysis (PCA) of edaphoclimatic properties in *Neltuma pallida* populations evaluated in the departments of Piura and Tumbes. Projection of edaphoclimatic variables and study localities onto the first two principal components, which together explain the largest proportion of total system variance (n = 631).](img_1.jpg){#fig:kix.pue33k4y909g}



## 

## Morphological diversity

The phenotypic states, relative frequencies, and Shannon–Weaver diversity index (H′) values for the qualitative traits evaluated are presented in [Table  @tbl:id.gkt0e0l3aa36]:. Considerable polymorphism was observed across qualitative traits, revealing notable phenotypic variability within *Neltuma pallida* populations. H′ values ranged from 0.55 to 1.30, with an overall mean of 1.01, indicating a high level of phenotypic diversity among the evaluated traits. This index reflects both the richness and evenness of phenotypic classes within each character.

The traits with the greatest diversity were fruit production (H′ = 1.30), tree form (H′ = 1.09), stem quality (H′ = 1.09), foliage quality (H′ = 1.07), and fruit quality (H′ = 1.00). All of these exceeded 1.0, suggesting a relatively even distribution across their phenotypic categories. In contrast, branching exhibited moderate phenotypic diversity, with a value of H′ = 0.55.

In terms of frequency distributions, tree form was dominated by individuals with intermediate morphology (37.88%), defined as trees with traits between a single stem with narrow branch angles (≤30°) and multistemmed forms with wider branching angles (>30°). For stem quality, the “moderate” class predominated (39.30%), representing trees with defects affecting 10–40% of the bole. Regarding fruit production, more than half of the trees evaluated (52.61%) did not produce fruits, while in fruit quality the “bitter” category was most frequent (53.41%). In foliage quality, the largest proportion of individuals (42.00%) exhibited foliage covering up to two-thirds of branches. Finally, branching showed a clear trend toward absence, with 83.04% of individuals lacking bifurcation.






| **SN**                                        | **Qualitative traits**                        | **Shannon-Weaver index**                      | **Descriptor's states**                       | **Frequency**                                 | **Proportion (%)**                             |
|-----------------------------------------------|-----------------------------------------------|-----------------------------------------------|-----------------------------------------------|-----------------------------------------------|------------------------------------------------|
| 1                                             | Tree form                                     | 1.09                                          | 1 = Multi-stemmed (<1.2 m) with branches >30° | 195                                           | 30.9                                           |
|                                               |                                               |                                               | 2 = Intermediate                              | 239                                           | 37.88                                          |
|                                               |                                               |                                               | 3 = Single stem (<1.2 m) with branches ≤30°   | 197                                           | 31.22                                          |
| 2                                             | Trunk quality                                 | 1.09                                          | 1 = Defective                                 | 195                                           | 30.9                                           |
|                                               |                                               |                                               | 2 = Fair with defects                         | 248                                           | 39.3                                           |
|                                               |                                               |                                               | 3 = No defects or only minor defects          | 188                                           | 29.79                                          |
| 3                                             | Forking                                       | 0.55                                          | 1 = Below DBH                                 | 25                                            | 3.96                                           |
|                                               |                                               |                                               | 2 = At DBH                                    | 82                                            | 13                                             |
|                                               |                                               |                                               | 3 = No forking                                | 524                                           | 83.04                                          |
| 4                                             | Fruit production                              | 1.3                                           | 0 = No fruits                                 | 332                                           | 52.61                                          |
|                                               |                                               |                                               | 1 = Up to 25 % of the branches                | 93                                            | 14.74                                          |
| 4                                             | Fruit quality                                 | 1                                             | 2 = Up to 50 %                                | 117                                           | 18.54                                          |
|                                               |                                               |                                               | 3 = Up to 75 %                                | 52                                            | 8.24                                           |
|                                               |                                               |                                               | 4 = Up to 100 %                               | 37                                            | 5.86                                           |
| 5                                             | Fruit quality                                 | 1                                             | 0 = Very bitter                               | 337                                           | 53.41                                          |
| 5                                             | Foliage quality                               | 1.07                                          | 1 = Bitter                                    | 14                                            | 2.22                                           |
|                                               |                                               |                                               | 2 = Sweet                                     | 223                                           | 35.34                                          |
|                                               |                                               |                                               | 3 = Very sweet                                | 57                                            | 9.03                                           |
| 6                                             | Foliage quality                               | 1.07                                          | 1 = Foliage on up to 1/3 of the branches      | 139                                           | 22.03                                          |
|                                               |                                               |                                               | 2 = Up to 2/3 of the branches                 | 265                                           | 42                                             |
|                                               |                                               |                                               | 3 = Full foliage on all branches              | 227                                           | 35.97                                          |




: Phenotypic diversity of qualitative traits in *Neltuma pallida* populations from Piura and Tumbes. Observed states of qualitative descriptors and Shannon–Weaver diversity index (H′) values are presented for each trait. Diversity levels were categorized as low (H′ = 0.10–0.40), intermediate (H′ = 0.40–0.60), and high (H′ > 0.60). The analysis was based on 631 observations (n = 631). {#tbl:id.gkt0e0l3aa36}

## Phenotypic diversity in quantitative traits

To evaluate phenotypic diversity in quantitative traits, variability was analyzed across localities. The results revealed pronounced heterogeneity in the performance of the dendrometric traits assessed, highlighting significant structural differences among *Neltuma pallida* populations **([Figure 3](?tab=t.ecc2pbe3h01k#bookmark=id.je3l5aw49xmv)).

Analysis of diameter at breast height (DBH) showed significant differences among localities (p < 0.001). Fundo Valdez (50.07 cm), Monte Azul (46.62 cm), and KM 190 (45.77 cm) exhibited the highest mean values, indicating individuals with greater stem diameter development. In contrast, ISA REP (15.59 cm) and Rica Playa (16.06 cm) displayed the lowest values, reflecting populations with reduced bole thickness ([Figure 3a](?tab=t.ecc2pbe3h01k#bookmark=id.je3l5aw49xmv)). 

For total tree height, statistically significant differences were also detected among localities (p < 0.001). The tallest individuals were recorded at Monte Azul (14.44 m), Fundo Valdez (12.33 m), and Saman Chico (11.40 m), while ISA REP (4.67 m) and Rica Playa (7.95 m) presented the shortest trees ([Figure 3b](?tab=t.ecc2pbe3h01k#bookmark=id.je3l5aw49xmv)).

Crown diameter likewise exhibited significant variability across localities (p < 0.001). Monte Azul (14.42 m), Saman Chico (14.25 m), and CC Ignacio Távara (14.02 m) had the largest average crown diameters, reflecting individuals with broader architectures and potentially greater dominance. Conversely, ISA REP (6.04 m) and SENASA (6.68 m) displayed the smallest crowns ([Figure 3c](?tab=t.ecc2pbe3h01k#bookmark=id.je3l5aw49xmv)). 

Finally, for height to the first branching, significant differences were observed among localities (p < 0.001). Fundo Valdez (4.08 m), SENASA (3.21 m), and Monte Azul (3.20 m) recorded the greatest branching heights, suggesting trees with cleaner boles. In contrast, ISA REP (1.32 m) and Chanchape (1.71 m) exhibited the lowest values ([Figure 3d](?tab=t.ecc2pbe3h01k#bookmark=id.je3l5aw49xmv)).

# ![Distribution of quantitative morphological traits in *Neltuma pallida* populations evaluated across 13 localities in the departments of Piura and Tumbes. (a) Diameter at breast height (DBH). (b) Total height. (c) Crown diameter. (d) Height to the first branching. Distributions are based on the evaluation of 631 individuals, allowing the characterization of phenotypic variability among localities and providing inputs for germplasm conservation and selection. Different letters indicate statistically significant differences according to Tukey’s multiple comparison test (p < 0.05).](img_2.jpg){#fig:id.je3l5aw49xmv}



Hierarchical cluster analysis, based on the combination of qualitative and quantitative traits previously evaluated, grouped the 13 study localities into four distinct clusters. This classification reflects patterns of phenotypic variation in *Neltuma pallida* populations, highlighting relationships between structural and functional traits of individuals and their geographic origin ([Figure 4](?tab=t.ecc2pbe3h01k#bookmark=id.yc0capj6bnvr)).

Cluster I included the localities Saman Chico and Monte Azul, distinguished by individuals with the highest average values of DBH (37.33 cm and 46.62 cm, respectively), total height (11.40 m and 14.44 m), and crown diameter (14.25 m and 14.42 m). These trees also exhibited high fruit production, with very sweet fruits, and dense foliage providing full branch coverage.

Cluster II comprised the localities Kurt Beer, Chanchape, and Fundo Valdez. This group displayed intermediate DBH values (33.63 cm, 34.20 cm, and 50.07 cm, respectively), total heights ranging from 9.77 m to 12.33 m, and crown diameters between 10.50 m and 12.40 m. Qualitatively, trees in this group bore fruits distributed across up to 75% of branches, accompanied by dense foliage covering two-thirds to the entirety of branches.

Cluster III was formed by the localities Marginal Forest, Pedregal, CC Ignacio Távara, and KM 190. This group was characterized by individuals with relatively high DBH values, ranging from 30.81 cm (Pedregal) to 45.77 cm (KM 190). Total heights remained intermediate (8.49–11.13 m), while crown diameters varied between 8.30 m and 14.02 m. Qualitatively, trees presented fruits distributed across 25–50% of branches, with flavors ranging from sour to sweet, and partial foliage coverage limited to two-thirds of branches.

Cluster IV included the localities INIA, Rica Playa, ISA REP, and SENASA, which grouped individuals with the lowest average values for all evaluated traits. DBH ranged from 15.59 cm (ISA REP) to 23.59 cm (SENASA), total height varied between 4.67 m and 9.80 m, and crown diameter between 6.04 m and 7.66 m. These localities were also characterized by low fruit production, frequent stem defects, sparse or low-quality foliage, and a predominance of bitter-tasting fruits.

# ![Cluster analysis of 13 *Neltuma pallida* localities evaluated in the departments of Piura and Tumbes. Clustering was performed using Euclidean distance as the dissimilarity measure and the Weighted Pair Group Method using Centroids (WPGMC). The optimal number of clusters was determined using the average silhouette coefficient, allowing the identification of locality groups with similar morphological and phenotypic characteristics.](img_3.jpg){#fig:id.yc0capj6bnvr}



## Heritability and plus tree selection

Understanding the genetic improvement potential of *Neltuma pallida* in the regions of Piura and Tumbes requires quantifying the proportion of phenotypic variation attributable to genetic versus environmental effects. In this study, phenotypic characterization of 631 individuals belonging to two populations - one in Tumbes and one in Piura - enabled the estimation of genetic variance (Vg), error variance (Ve), total phenotypic variance (Vp), and broad-sense heritability (H²) for seven morphological and functional traits across five localities in Tumbes and eight in Piura. The values of H² varied considerably among traits and populations, allowing the identification of those with greater genetic control and, therefore, higher potential for selection and breeding programs.

In the Tumbes population, the trait with the highest heritability was fruit production (fruit\_production) with H² = 0.92, indicating a stable, genetically controlled phenotypic characteristic. This was followed by tree form (tree\_form, H² = 0.71) and diameter at breast height (dbh, H² = 0.78), both showing favorable variance component ratios for genetic expression (Vg:Vp:Ve = 1:1.4:3.2 and 1:1.3:2.3, respectively). Total tree height (total\_height) also displayed moderate heritability (H² = 0.78), with genetic variance exceeding error variance. In contrast, branch height (branch\_height) exhibited the lowest H² (0.28) in this population.

In the Piura population, a similar pattern was observed, though with generally higher heritability values. Fruit production again exhibited high heritability (H² = 0.95). Likewise, total height (H² = 0.78), stem diameter (dbh, H² = 0.67), and tree form (H² = 0.68) showed consistently strong genetic expression in key structural traits. Additionally, crown diameter (H² = 0.75), trunk quality (trunk\_quality, H² = 0.72), and branch height (H² = 0.73) also presented high values, suggesting favorable prospects for their use in selection programs.





: Morphological and phenotypic characterization of *Neltuma pallida* populations across 13 localities in the departments of Piura and Tumbes, Peru. Variance components and broad-sense heritability (H²) were estimated following the approach of [Cullis et al., (2006)](https://www.zotero.org/google-docs/?49TOo9). Variance components include: genetic variance (Vg), phenotypic variance (Vp), and error variance (Ve). The “Ratio” represents the variance ratio relative to Vg for each component (Vg/Vg : Vp/Vg : Ve/Vg), serving as an indicator of the relative contribution of genetic versus environmental effects. The analysis was based on 631 individuals. {#tbl:id.5pgyfuz4ou7f}




| **Population**   | **Trait**        | **Localities**   | **mean**         | **std**          | **min**          | **max**          | **V.g**          | **V.e**          | **V.p**          | **Heritability** | **Ratio**         |
|------------------|------------------|------------------|------------------|------------------|------------------|------------------|------------------|------------------|------------------|------------------|-------------------|
| Tumbes           | DBH              | 5                | 20.82            | 5.83             | 15.6             | 28.34            | 28.64            | 65.91            | 36.88            | 0.78             | 1:1.3:2.3         |
|                  | Crown diameter   | 5                | 7.84             | 1.28             | 6.05             | 9.59             | 1.27             | 9.38             | 2.45             | 0.52             | 1:1.9:7.4         |
|                  | Branch height    | 5                | 2.13             | 0.56             | 1.32             | 2.7              | 0.28             | 0.87             | 0.38             | 0.72             | 1:1.4:3.2         |
|                  | Total height     | 5                | 7.59             | 1.66             | 4.68             | 8.79             | 2.53             | 4.93             | 3.14             | 0.8              | 1:1.2:1.9         |
|                  | Tree form        | 5                | 2.16             | 0.3              | 1.77             | 2.55             | 0.08             | 0.26             | 0.11             | 0.71             | 1:1.4:3.2         |
|                  | Trunk quality    | 5                | 1.9              | 0.34             | 1.38             | 2.33             | 0.1              | 0.44             | 0.16             | 0.65             | 1:1.5:4.4         |
|                  | Fruit production | 5                | 1.18             | 0.26             | 1                | 1.57             | 0.06             | 0.05             | 0.07             | 0.92             | 1:1.1:0.7         |
| Piura            | DBH              | 8                | 38.48            | 8.75             | 23.6             | 50.07            | 67.44            | 269.9            | 101.18           | 0.67             | 1:1.5:4           |
|                  | Crown diameter   | 8                | 12.05            | 2.49             | 6.69             | 14.43            | 6                | 16.29            | 8.03             | 0.75             | 1:1.3:2.7         |
|                  | Branch height    | 8                | 2.72             | 0.77             | 1.59             | 3.89             | 0.53             | 2.07             | 0.79             | 0.67             | 1:1.5:3.9         |
|                  | Total height     | 8                | 11.01            | 1.64             | 9.77             | 14.44            | 2.62             | 5.81             | 3.34             | 0.78             | 1:1.3:2.2         |
|                  | Tree form        | 8                | 1.92             | 0.45             | 1.32             | 2.5              | 0.18             | 0.68             | 0.27             | 0.68             | 1:1.5:3.7         |
|                  | Trunk quality    | 8                | 2.11             | 0.43             | 1.58             | 2.64             | 0.17             | 0.53             | 0.24             | 0.72             | 1:1.4:3           |
|                  | Fruit production | 8                | 2.56             | 1.31             | 1                | 4.58             | 1.7              | 0.06             | 1.71             | 1                | 1:1:0             |




A multivariate analysis was conducted, excluding variables with low contributions to explained variance. After preliminary evaluation, branching and branch height were removed due to their minimal influence on the multivariate structure of the dataset.

Principal component analysis (PCA) was then applied to explore phenotypic variability among individuals. The first two principal components explained 71.00% of the total system variance, with Dim 1 accounting for 54.30% and Dim 2 for 16.70%. In Dim 1, the variables contributing most to variance were crown diameter (15.75%), fruit production (15.02%), fruit quality (14.89%), and total height (14.29%). Dim 2 was mainly influenced by tree form (40.75%) and trunk quality (24.58%) ([Figure 5](?tab=t.ecc2pbe3h01k#bookmark=id.59gj1fd1tlfe)).

The variable biplot showed clear groupings according to their contribution and orientation within the factorial space ([Figure 5a](?tab=t.ecc2pbe3h01k#bookmark=id.59gj1fd1tlfe)). Three main associations were identified: (i) tree form and trunk quality aligned with Dim 2; (ii) DBH, total height, and crown diameter strongly correlated with Dim 1; and (iii) fruit production, fruit quality, and foliage quality, also associated with Dim 1 but positioned toward the positive quadrant of the axis ([Figure 5a](?tab=t.ecc2pbe3h01k#bookmark=id.59gj1fd1tlfe)).

At the individual level, trees from Monte Azul, Samán Chico, and Fundo Valdez clustered in the region associated with higher values of DBH, total height, and crown diameter ([Figure 5b](?tab=t.ecc2pbe3h01k#bookmark=id.59gj1fd1tlfe)). Monte Azul and Samán Chico were further distinguished by high fruit production, very sweet fruit quality, and excellent foliage quality, characterized by leaf coverage over the entirety of branches. In contrast, trees from Rica Playa, ISA REP, and SENASA occupied the opposite quadrant, associated with lower values of tree form and trunk quality ([Figure 5b](?tab=t.ecc2pbe3h01k#bookmark=id.59gj1fd1tlfe)). 

# ![Principal component analysis (PCA) of morphological and phenotypic traits in *Neltuma pallida* populations from Piura and Tumbes. (a) Projection of morphological and phenotypic variables onto the first two principal components, which explain the largest proportion of system variance. (b) Distribution of individuals grouped by locality in the multivariate space defined by the principal components, based on morphological and phenotypic characteristics. The analysis was conducted on 631 individuals (n = 631).](img_4.jpg){#fig:id.59gj1fd1tlfe}

Eight trees from the Monte Azul locality in Piura were identified as plus trees. These individuals were distinguished by their high vigor, well-formed boles, strong fruiting capacity, and dense foliage cover. They met all favorable qualitative and quantitative selection criteria and displayed outstanding morpho-phenotypic expression compared with the rest of the population. Their superior attributes included abundant fruit production, vigorous biomass development, and close correspondence with favorable habitat conditions and conservation status.

Quantitatively, the plus trees exhibited the highest values for the evaluated traits. Mean DBH reached 59.52 cm. Branching height ranged from 4.20 m to 6.20 m, substantially exceeding the population mean, which rarely surpassed 3 m. Total height averaged 16.05 m, considered optimal for fully developed individuals. Crown diameter averaged 15.83 m, reflecting a globose architecture with abundant biomass.

Qualitatively, all plus trees exhibited single stems with no bifurcations. Tree form was classified as dominant single-stemmed, while trunk quality was rated as “good,” meaning free of or with only minimal defects. All plus trees produced abundant fruits, distributed across 50–100% of branches, with fruits consistently rated as sweet to very sweet. Foliage quality was also outstanding, with leaf cover extending over at least two-thirds to the entirety of branches.

# **DISCUSSION**

*Neltuma pallida*, commonly known as algarrobo, is a key leguminous forest species of northern Peru’s dry forests, adapted to warm climates and arid soils, and recognized for its high ecological, economic, and sociocultural value [[14]](https://www.zotero.org/google-docs/?1tJuL4). However, the species is currently threatened by pests, diseases, and the progressive degradation of its natural ecosystem [[46]](https://www.zotero.org/google-docs/?aBeKNR). In this study, we evaluated the morphological and phenotypic diversity of *N. pallida* across 13 localities with contrasting edaphoclimatic conditions. Our results revealed significant intra- and inter-population polymorphism, reflecting genetic variability among the studied populations. Estimation of heritability coefficients further enabled the identification of traits under stronger genetic control, thus with higher potential for selection. Consequently, a group of individuals with superior phenotypes was identified as ideal candidates for incorporation into a germplasm bank to support future breeding programs aimed at conservation and restoration of this species.

## Edaphoclimatic conditions

The edaphoclimatic analysis revealed marked differences in soil, climatic, and physiographic variables among the study sites ([Figure 2](?tab=t.ecc2pbe3h01k#bookmark=id.29te1b5ba2dj)), consistent with evidence that such factors influence vegetation distribution and development [[47,48]](https://www.zotero.org/google-docs/?OHypcw). Soil variables exerted the strongest influence on the morpho-phenotypic expression of N. pallida. Monte Azul and Chanchape showed higher concentrations of N, P, K, and organic matter (OM), associated with more vigorous individuals, larger structural dimensions, and superior phenotypes in fruit production and foliage quality. By contrast, Rica Playa e ISA REP exhibited higher CaCO₃ levels and alkaline pH, associated with unfavorable morpho-phenotypic traits. These patterns may be explained by phosphorus availability - often limiting in nutrient-poor soils [[49]](https://www.zotero.org/google-docs/?2zi00I) - as well as by organic matter, which improves both soil fertility and structure [[50]](https://www.zotero.org/google-docs/?yJsMMh), and pH, which affects nutrient availability and microbial activity [[51,52]](https://www.zotero.org/google-docs/?D8RK26).

This evidence supports the hypothesis that the reduced vigor observed in ISA REP and Rica Playa may be linked to salinity stress resulting from high CaCO₃ content and elevated soil pH [[53]](https://www.zotero.org/google-docs/?XkMThP). Similar responses were reported by Meglioli [[54]](https://www.zotero.org/google-docs/?CXLJn8), in *Neltuma flexuosa* and *N. chilensis,* where reductions in height and aboveground biomass under saline stress were observed, although tolerant individuals were also detected, suggesting a role for genetic variability. Samán Chico provides further evidence of this pattern, as despite high CaCO₃ and electrical conductivity (EC), it contained well-developed individuals, suggesting potential genetic tolerance to salinity [[55,56]](https://www.zotero.org/google-docs/?fD4AeC).

Climatic variables such as precipitation (pp), Tmin, and Tmean were slightly higher in Rica Playa, Pedregal, and Marginal forest, with lower relative humidity (RH), while Monte Azul and Chanchape presented intermediate values ([Figure 2](?tab=t.ecc2pbe3h01k#bookmark=id.29te1b5ba2dj)). Physiographic variables (e.g., distance to water bodies [DW], slope, and elevation [SLI]) showed no consistent influence on phenotypic traits. Although Pedregal, KM 190, and Fundo Valdez were closer to water bodies, and CC Ignacio Távara, KM 190, and Monte Azul were at higher elevations, these differences did not correlate with phenotypic variation. This aligns with Sadia [[57]](https://www.zotero.org/google-docs/?Kf3ktw), who emphasized that edaphic factors such as pH, OM, P, and K availability are key determinants of plant distribution, but their effects must be understood in interaction with biotic and abiotic variables. Similarly, Barboza [[58]](https://www.zotero.org/google-docs/?O52Kjl) identified climatic variables (mean temperature of the wettest quarter, maximum temperature of the warmest month, elevation, and annual precipitation) as critical for *N. pallida* suitability, but in our study the relative climatic homogeneity reduced their influence. These findings are consistent with Baselly-Villanueva and Rufasto-Peralta [[59,60]](https://www.zotero.org/google-docs/?tap7oo), who observed that at local scales, edaphic variables are often more determinant than climatic or physiographic ones. Overall, the interaction between soil, environment, and genetic background must be considered in conservation, restoration, and breeding strategies for *N. pallida.*

## Morphological diversity in algarrobo populations

The morpho-phenotypic characterization revealed high polymorphism within and among populations in Piura and Tumbes ([Table  @tbl:id.gkt0e0l3aa36]:), suggesting considerable genetic diversity. The Shannon–Weaver diversity index (H′) showed high values, reflecting broad variability among traits [[61,62]](https://www.zotero.org/google-docs/?fRBPwk). Fruit production displayed the greatest diversity, whereas branching presented moderate diversity. Among dendrometric traits, analysis of variance indicated significant heterogeneity ([Figure 3](?tab=t.ecc2pbe3h01k#bookmark=id.je3l5aw49xmv)), suggesting structural differences among populations. Similar findings were reported by Bessega [[63]](https://www.zotero.org/google-docs/?nMJJkx) in *N. flexuosa*, where differences in height and basal diameter were partly genetically based but modulated by local environmental conditions. Likewise, Vega [[64]](https://www.zotero.org/google-docs/?Z1u4o1) argued that *N. alba* exhibits strong adaptive capacity to environmental heterogeneity, favoring local adaptation processes.

Our results are also consistent with Esparza-Orozco [[65]](https://www.zotero.org/google-docs/?OPMntU), who identified significant phenotypic differences among *Neltuma* populations associated with geographic origin. These findings suggest that phenology and morphology in this genus are strongly influenced by ecological factors. Vidaković [[66]](https://www.zotero.org/google-docs/?S3cFSS) further emphasized that interactions between environment and geography can explain observed phenotypic variation, reflecting potential processes of isolation by environment and by distance. In our study, Monte Azul, Chanchape, and Samán Chico (Piura) were distinguished by superior morphological and phenotypic performance, while Rica Playa, ISA REP, and SENASA (Tumbes) were associated with lower performance. This pattern supports the hypothesis of simultaneous environmental and geographic isolation shaping genetic and phenotypic structuring in *N. pallida* populations. According to Wang [[67]](https://www.zotero.org/google-docs/?sCRxP2), high phenotypic variation often reflects high genetic diversity; thus, phenotypic evaluation represents a direct and effective approach for estimating diversity in forest germplasm resources.

## Genetic influence and identification of plus trees

The genetic influence observed in *N. pallida* aligns with patterns reported in other forest species from contrasting environments, where high heritability coefficients predict genetic gains in selection programs. In this study, fruit production exhibited high heritability (H² ≈ 0.92–1.00), confirming strong genetic control and limited environmental influence, ensuring high response to selection. Moderate-to-high heritability values for structural traits such as DBH, total height, and crown diameter also suggest that vegetative growth traits are suitable targets for breeding programs. These findings are consistent with recent studies in *Pinus pinaster* and *Juglans mandshurica,* where size-related traits displayed higher heritability than form-related traits, highlighting their value in early breeding cycles [[68,69]](https://www.zotero.org/google-docs/?oZn3Hz). Prioritizing traits with high heritability and temporal stability, such as bole straightness or branch insertion angle, optimizes selection accuracy while minimizing environmental and genotype × environment (G×E) effects, which is crucial in heterogeneous ecosystems such as dry forests.

In this study, plus tree identification was based on individual assessment, allowing the selection of outstanding trees in terms of fruit production, vegetative vigor, and crown architecture across 13 localities in Piura and Tumbes. Approximately 90% of individuals with superior traits were concentrated in these regions, consistent with Castro [[18]](https://www.zotero.org/google-docs/?550Osd). While phenotypic selection was used here, comparisons with neighboring trees can further reduce microsite and age-related biases, increasing accuracy of genetic estimates [[70]](https://www.zotero.org/google-docs/?DSQ58Z). Multivariate analyses confirmed that individuals from Monte Azul, Chanchape, and Samán Chico clustered in dimensions associated with higher productivity and biomass. Consolidating these candidates requires validation through progeny tests and clonal banks, as well as the integration of modern tools such as high-throughput phenotyping and genomic selection, which have proven effective in accelerating breeding cycles and mitigating G×E effects in forest programs [[18,71]](https://www.zotero.org/google-docs/?6myR3d). The eight selected individuals provide a robust foundation for establishing seed orchards and germplasm banks, contributing to the productive and sustainable restoration of Peruvian dry forests.

## Limitations and perspectives

Despite progress in identifying superior *N. pallida* individuals, questions remain regarding whether the highlighted traits reflect true genetic potential or are mainly influenced by local edaphoclimatic conditions. Soil fertility heterogeneity, salinity levels, and nutrient availability likely conditioned phenotypic expression, raising the risk of overestimating individuals favored by environmental plasticity rather than genetic superiority. Future studies should complement morpho-phenotypic selection with molecular marker analyses and progeny testing to more precisely disentangle environmental effects. Integrating these approaches will strengthen breeding programs and ensure that selected individuals not only express desirable traits under specific site conditions but also maintain adaptive advantages - such as abiotic stress tolerance and growth potential - across diverse ecological scenarios.

# **CONCLUSIONS**

The morpho-phenotypic characterization of *Neltuma pallida* in the regions of Piura and Tumbes revealed substantial intra- and inter-population variability, reflected in the high degree of polymorphism observed. Edaphoclimatic differences among localities influenced the expression of evaluated traits, while heritability estimates enabled the identification of characters with greater potential response to selection. These findings led to the identification of eight superior individuals classified as plus trees, providing a foundation for the establishment of germplasm banks and the development of genetic improvement programs aimed at the conservation and ecological restoration of this species within tropical dry forest ecosystems.

# **PATENTS**

**Author Contributions**

Conceptualization, XX, XX, and XX; methodology, XX; formal analysis, XX; investigation, XX; data curation, XX; writing—original draft preparation, XX; writing—review and editing, XX; visualization, XX. All authors have read and agreed to the published version of the manuscript.

**Funding**

This work was funded by the National Institute of Agricultural Innovation (INIA), Peru, through investment project No. 2472190 “El Chira.”

**Data Availability Statement**

The original contributions presented in this study are included in the article and its supplementary material. Reproducible datasets and data analysis scripts are provided in Supplementary File 1 and are publicly accessible via the GitHub repository at:  [https://github.com/Sebass96/INIA\_algarrobo.git](https://github.com/Sebass96/INIA_algarrobo.git)

**Acknowledgments**

The authors would like to thank the Directorate of Studies and Research of the National Forest and Wildlife Service (SERFOR), Peru, for their valuable support during field data collection.

**Conflict of Interest**

The authors declare no conflict of interest.





# **REFERENCES**

[1. ](https://www.zotero.org/google-docs/?WXr7jy)	[Hughes, C.E.; Ringelberg, J.J.; Lewis, G.P.; Catalano, S.A. Disintegration of the Genus *Prosopis* L. (Leguminosae, Caesalpinioideae, Mimosoid Clade). *PhytoKeys* **2022**, *205*, 147–189, doi:10.3897/phytokeys.205.75379. ](https://www.zotero.org/google-docs/?WXr7jy)

[2. ](https://www.zotero.org/google-docs/?WXr7jy)	[Bessega, C.; Saidman, B.O.; Darquier, M.R.; Ewens, M.; Sánchez, L.; Rozenberg, P.; Vilardi, J.C. Consistency between Marker- and Genealogy-Based Heritability Estimates in an Experimental Stand of *Prosopis Alba* (Leguminosae). *American Journal of Botany* **2009**, *96*, 458–465, doi:10.3732/ajb.0800074. ](https://www.zotero.org/google-docs/?WXr7jy)

[3. ](https://www.zotero.org/google-docs/?WXr7jy)	[Grados, N.; Cruz, G.; Albán, L.; Felker, P. Peruvian *Prosopis Pallida*: Its Potential to Provide Human and Livestock Food for Tropical Arid Lands of the World. In *Prosopis as a Heat Tolerant Nitrogen Fixing Desert Food Legume*; Puppo, M.C., Felker, P., Eds.; Academic Press, 2022; pp. 241–251 ISBN 978-0-12-823320-7. ](https://www.zotero.org/google-docs/?WXr7jy)

[4. ](https://www.zotero.org/google-docs/?WXr7jy)	[Beresford-Jones, D.G.; T, S.A.; Whaley, O.Q.; Chepstow-Lusty, A.J. The Role of *Prosopis* in Ecological and Landscape Change in the Samaca Basin, Lower Ica Valley, South Coast Peru from the Early Horizon to the Late Intermediate Period. *Latin American Antiquity* **2009**, *20*, 303–332, doi:10.1017/S1045663500002650. ](https://www.zotero.org/google-docs/?WXr7jy)

[5. ](https://www.zotero.org/google-docs/?WXr7jy)	[Beresford-Jones, D.G.; Whaley, O.Q. *Prosopis* in the History of the Coast of Peru. In *Prosopis as a Heat Tolerant Nitrogen Fixing Desert Food Legume*; Puppo, M.C., Felker, P., Eds.; Academic Press, 2022; pp. 95–103 ISBN 978-0-12-823320-7. ](https://www.zotero.org/google-docs/?WXr7jy)

[6. ](https://www.zotero.org/google-docs/?WXr7jy)	[Duval, V.S.; Cámara-Artigas, R. Diversidad y captura de carbono en un bosque secundario de caldén (*Prosopis caldenia*) en La Pampa, Argentina. *Estudios Geográficos* **2021**, *82*, e073–e073, doi:10.3989/estgeogr.202184.084. ](https://www.zotero.org/google-docs/?WXr7jy)

[7. ](https://www.zotero.org/google-docs/?WXr7jy)	[van Zonneveld, M.; Thomas, E.; Castañeda-Álvarez, N.P.; Van Damme, V.; Alcazar, C.; Loo, J.; Scheldeman, X. Tree Genetic Resources at Risk in South America: A Spatial Threat Assessment to Prioritize Populations for Conservation. *Diversity and Distributions* **2018**, *24*, 718–729, doi:10.1111/ddi.12724. ](https://www.zotero.org/google-docs/?WXr7jy)

[8. ](https://www.zotero.org/google-docs/?WXr7jy)	[Montano Fuentes, M.E.; Durán Enríquez, C.A.; Duarte, C. Destrucción del Bosque Seco Tropical en el Valle Geográfico del Río Cauca. *Historia Ambiental Latinoamericana y Caribeña (HALAC) revista de la Solcha* **2022**, *12*, 287–324, doi:10.32991/2237-2717.2022v12i3.p287-324. ](https://www.zotero.org/google-docs/?WXr7jy)

[9. ](https://www.zotero.org/google-docs/?WXr7jy)	[Vera, E.; Cruz, C.; Barboza, E.; Salazar, W.; Canta, J.; Salazar, E.; Vásquez, H.V.; Arbizu, C.I. Change of Vegetation Cover and Land Use of the Pómac Forest Historical Sanctuary in Northern Peru. *Int. J. Environ. Sci. Technol.* **2024**, *21*, 8919–8930, doi:10.1007/s13762-024-05597-6. ](https://www.zotero.org/google-docs/?WXr7jy)

[10. ](https://www.zotero.org/google-docs/?WXr7jy)	[Juárez, G.; González, U. Coleópteros (Insecta: Coleoptera) Del Campus de La Universidad de Piura-Perú. *The biologist* **2016**, *14*, 183–198. ](https://www.zotero.org/google-docs/?WXr7jy)

[11. ](https://www.zotero.org/google-docs/?WXr7jy)	[Juárez-Noé, G.; González-Coronado, U. Lista taxonómica actualizada de los insectos asociados a <em>Prosopis pallida</em> (Humb. & Bonpl. ex. Wild.) Kunth (Fabaceae) de la región Piura, Perú. *Graellsia* **2020**, *76*, e110–e110, doi:10.3989/graellsia.2020.v76.263. ](https://www.zotero.org/google-docs/?WXr7jy)

[12. ](https://www.zotero.org/google-docs/?WXr7jy)	[SERFOR; SENASA; INIA Guía para la identificación de insectos asociados al algarrobo *Prosopis pallida* (Humb. &. Bonpl. Ex Willd.) Kunth. Volumen II. Piura. *Servicio Nacional Forestal y de Fauna Silvestre* **2022**. ](https://www.zotero.org/google-docs/?WXr7jy)

[13. ](https://www.zotero.org/google-docs/?WXr7jy)	[Gagné, R.J.; Whaley, O.Q. The Larva of *Enallodiplosis Discordis* (Diptera: Cecidomyiidae: Cecidomyiidinae), a Pest of Prosopis Spp. (Fabaceae) in Peru and Chile. *went* **2020**, *122*, 243–247, doi:10.4289/0013-8797.122.1.243. ](https://www.zotero.org/google-docs/?WXr7jy)

[14. ](https://www.zotero.org/google-docs/?WXr7jy)	[La Torre, R.; Hamilton, J.P.; Saucedo-Bazalar, M.; Caycho, E.; Vaillancourt, B.; Wood, J.C.; Ramírez, M.; Buell, C.R.; Orjeda, G. A Chromosome-Level Genome Assembly of the Peruvian Algarrobo (*Neltuma Pallida*) Provides Insights on Its Adaptation to Its Unique Ecological Niche. *G3 Genes|Genomes|Genetics* **2025**, *15*, jkae283, doi:10.1093/g3journal/jkae283. ](https://www.zotero.org/google-docs/?WXr7jy)

[15. ](https://www.zotero.org/google-docs/?WXr7jy)	[Rosales-Islas, E.; Barrera-Tello, D.; Sánchez-González, A.; Galván-Hernández, D.M.; Hernández-León, S.; Octavio-Aguilar, P. Caracterización morfológica y genética de las poblaciones de *Abies* en Hidalgo, México: importancia de la identidad taxonómica para el aprovechamiento forestal. *Botanical Sciences* **2023**, *101*, 417–434, doi:10.17129/botsci.3203. ](https://www.zotero.org/google-docs/?WXr7jy)

[16. ](https://www.zotero.org/google-docs/?WXr7jy)	[Bessega, C.; Pometti, C.; Ewens, M.; Saidman, B.O.; Vilardi, J.C. Evidences of Local Adaptation in Quantitative Traits in *Prosopis Alba* (Leguminosae). *Genetica* **2015**, *143*, 31–44, doi:10.1007/s10709-014-9810-5. ](https://www.zotero.org/google-docs/?WXr7jy)

[17. ](https://www.zotero.org/google-docs/?WXr7jy)	[Castañeda-Garzón, S.L.; Argüelles-Cárdenas, J.H.; Zuluaga-Peláez, J.J.; Moreno-Barragán, J. Evaluación de la variabilidad fenotípica en *Simarouba amara* Aubl., mediante descriptores cualitativos y cuantitativos. *Orinoquia* **2021**, *25*, 67–77, doi:10.22579/20112629.656. ](https://www.zotero.org/google-docs/?WXr7jy)

[18. ](https://www.zotero.org/google-docs/?WXr7jy)	[Castro, W.; Seminario, R.; Nauray, W.; Acevedo-Juárez, B.; De-la-Torre, M.; Avila-George, H. Multispectral Drone Imagery Dataset for plus and Non-plus *Neltuma Pallida* Trees in Northern Peru. *Data in Brief* **2025**, *60*, 111645, doi:10.1016/j.dib.2025.111645. ](https://www.zotero.org/google-docs/?WXr7jy)

[19. ](https://www.zotero.org/google-docs/?WXr7jy)	[Ipinza, R.; Gutiérrez, B.; Emhart, V. *Mejora genética forestal operativa*; Universidad Austral de Chile: Valdivia, 1998; ISBN 978-956-288-072-5. ](https://www.zotero.org/google-docs/?WXr7jy)

[20. ](https://www.zotero.org/google-docs/?WXr7jy)	[Tomback, D.F.; Keane, R.E.; Schoettle, A.W.; Sniezko, R.A.; Jenkins, M.B.; Nelson, C.R.; Bower, A.D.; DeMastus, C.R.; Guiberson, E.; Krakowski, J.; et al. Tamm Review: Current and Recommended Management Practices for the Restoration of Whitebark Pine (*Pinus Albicaulis* Engelm.), an Imperiled High-Elevation Western North American Forest Tree. *Forest Ecology and Management* **2022**, *522*, 119929, doi:10.1016/j.foreco.2021.119929. ](https://www.zotero.org/google-docs/?WXr7jy)

[21. ](https://www.zotero.org/google-docs/?WXr7jy)	[Zobel, B.; Talbert, J. *Applied Forest Tree Improvement*; Caldwell, N.J. : Blackburn Press, 1984; ISBN 978-1-930665-81-1. ](https://www.zotero.org/google-docs/?WXr7jy)

[22. ](https://www.zotero.org/google-docs/?WXr7jy)	[Castañeda-Garzón, S.L.; Arenas-Rubio, I.; Argüelles-Cárdenas, J.H.; Montero-Cantillo, Y.D.; Gutiérrez-Berdugo, I.A.; Zuluaga-Peláez, J.J. Caracterización de una plantación juvenil de Cavanillesia platanifolia en la Zona Bananera Colombiana. *Madera y Bosques* **2023**, *29*, e2922495–e2922495, doi:10.21829/myb.2023.2922495. ](https://www.zotero.org/google-docs/?WXr7jy)

[23. ](https://www.zotero.org/google-docs/?WXr7jy)	[Paredes Ulloa, C.O.; Viafara, D.; Dueñas, Y.D.; Villalta Mazabanda, B.A.V.; Machado Cuzco, J.A.; Reyes Mera, J.J. Caracterización e Identificación de Especies Forestales Nativas como Fuentes de Semilla en la Amazonía Ecuatoriana. *Ciencia Latina Revista Científica Multidisciplinar* **2025**, *9*, 3242–3258, doi:10.37811/cl\_rcm.v9i2.17136. ](https://www.zotero.org/google-docs/?WXr7jy)

[24. ](https://www.zotero.org/google-docs/?WXr7jy)	[Ramírez-Galicia, K.; Ramírez-Herrera, C.; Gómez-Martínez, P.; López-Upton, J.; Mohedano-Caballero, L.; Rodríguez-Trejo, D.A.; Ramírez-Galicia, K.; Ramírez-Herrera, C.; Gómez-Martínez, P.; López-Upton, J.; et al. Variación y Heredabilidad En Altura, Diámetro y Volumen de *Pinus Patula* En Un Huerto Semillero Asexual En Huayacocotla, Veracruz, México. *Bosque (Valdivia)* **2024**, *45*, 187–194, doi:10.4067/s0717-92002024000100187. ](https://www.zotero.org/google-docs/?WXr7jy)

[25. ](https://www.zotero.org/google-docs/?WXr7jy)	[Chequer Charan, D.; Pometti, C.; Cony, M.; Vilardi, J.C.; Saidman, B.O.; Bessega, C. Genetic Variance Distribution of SSR Markers and Economically Important Quantitative Traits in a Progeny Trial of *Prosopis Chilensis* (Leguminosae): Implications for the ‘Algarrobo’ Management Programme. *Forestry (Lond)* **2021**, *94*, 204–218, doi:10.1093/forestry/cpaa026. ](https://www.zotero.org/google-docs/?WXr7jy)

[26. ](https://www.zotero.org/google-docs/?WXr7jy)	[López Lauenstein, D.; Vega, C.; Verga, A.; Lascano, H.R.; Marchelli, P. Local Adaptative Strategies for Coping with Drought Stress in *Neltuma Alba* (Leguminosae, Caesalpinioideae) Are Associated with the Timing of Leaf Senescence. *New Forests* **2025**, *56*, 28, doi:10.1007/s11056-025-10096-8. ](https://www.zotero.org/google-docs/?WXr7jy)

[27. ](https://www.zotero.org/google-docs/?WXr7jy)	[Revilla-Chávez, J.M.; Moraes, M.A. de; Revilla-Macedo, J.J.; Vergaray-Rengifo, W.F.; Mego-Pérez, J.A.; Saldaña-Dominguez, H.S.; Vigo-Ampuero, E.S.; Gonzales-Alvarado, A.C.; Manturano-Pérez, R.D.; Casas-Reátegui, R.; et al. Correlaciones, parámetros genéticos y fenotípicos en rasgos cuantitativos y cualitativos de *Swietenia macrophylla* en Ucayali, Perú. *Scientia Agropecuaria* **2024**, *15*, 409–417, doi:10.17268/sci.agropecu.2024.030. ](https://www.zotero.org/google-docs/?WXr7jy)

[28. ](https://www.zotero.org/google-docs/?WXr7jy)	[Hernández-Máximo, E.; Vargas-Hernández, J.J.; López-Upton, J.; Sánchez-Monsalvo, V. Structure of Genetic Variation in Vegetative Phenology of *Cedrela Odorata* L.: Implications for Tree Breeding. *New Forests* **2022**, *53*, 387–409, doi:10.1007/s11056-021-09862-1. ](https://www.zotero.org/google-docs/?WXr7jy)

[29. ](https://www.zotero.org/google-docs/?WXr7jy)	[POWER, D.A.V. NASA POWER | Data Access Viewer (DAV) Available online: https://power.larc.nasa.gov/data-access-viewer/ (accessed on 22 July 2025). ](https://www.zotero.org/google-docs/?WXr7jy)

[30. ](https://www.zotero.org/google-docs/?WXr7jy)	[Ministerio del Ambiente, M. *Guía de inventario de la flora y vegetación*; 2015; ](https://www.zotero.org/google-docs/?WXr7jy)

[31. ](https://www.zotero.org/google-docs/?WXr7jy)	[Roque, E.A.R.; Barrena Arroyo, V.M.; Ocaña Canales, J.C. Tamaño óptimo de parcela de inventarios forestales en bosques secos (Lambayeque, Perú). *Ciencia y Práctica* **2023**, *3*, doi:10.52109/cyp2023649. ](https://www.zotero.org/google-docs/?WXr7jy)

[32. ](https://www.zotero.org/google-docs/?WXr7jy)	*[Soil Sampling and Methods of Analysis](https://www.zotero.org/google-docs/?WXr7jy)​*[; Carter, M.R., Gregorich, E.G., Eds.; 2nd ed.; CRC Press: Boca Raton, 2007; ISBN 978-0-429-12622-2. ](https://www.zotero.org/google-docs/?WXr7jy)

[33. ](https://www.zotero.org/google-docs/?WXr7jy)	[Alban, L.; Matorel, M.; Romero, J.; Grados, N.; Cruz, G.; Felker, P. Cloning of Elite, Multipurpose Trees of the *Prosopis Juliflora/Pallida* Complex in Piura, Peru. *Agroforestry Systems* **2002**, *54*, 173–182, doi:10.1023/A:1016093106338. ](https://www.zotero.org/google-docs/?WXr7jy)

[34. ](https://www.zotero.org/google-docs/?WXr7jy)	[Cullis, B.R.; Smith, A.B.; Coombes, N.E. On the Design of Early Generation Variety Trials with Correlated Data. *JABES* **2006**, *11*, 381–393, doi:10.1198/108571106X154443. ](https://www.zotero.org/google-docs/?WXr7jy)

[35. ](https://www.zotero.org/google-docs/?WXr7jy)	[Schmidt, P.; Hartung, J.; Rath, J.; Piepho, H.-P. Estimating Broad-Sense Heritability with Unbalanced Data from Agricultural Cultivar Trials. *Crop Science* **2019**, *59*, 525–536, doi:10.2135/cropsci2018.06.0376. ](https://www.zotero.org/google-docs/?WXr7jy)

[36. ](https://www.zotero.org/google-docs/?WXr7jy)	[R Core Team R: A Language and Environment for Statistical Computing 2025. ](https://www.zotero.org/google-docs/?WXr7jy)

[37. ](https://www.zotero.org/google-docs/?WXr7jy)	[Allaire, J.J.; Dervieux, C.; Software, P.; PBC; Woodhull, G. Quarto: R Interface to “Quarto” Markdown Publishing System. **2025**, doi:10.32614/CRAN.package.quarto. ](https://www.zotero.org/google-docs/?WXr7jy)

[38. ](https://www.zotero.org/google-docs/?WXr7jy)	[Marcelo-Bazán, F.E.; Mantilla-Chávez, W.; Paredes-Pajares, K.P.; Chávez-Cercado, D.M.; Baselly-Villanueva, J.R.; Álvarez-Álvarez, P. Identification of the Optimal Substrate for Sexual Propagation of *Cinchona Officinalis* L.: Implications for Conservation and Sustainable Use. *For. Sci.* **2025**, *71*, 397–422, doi:10.1007/s44391-025-00018-8. ](https://www.zotero.org/google-docs/?WXr7jy)

[39. ](https://www.zotero.org/google-docs/?WXr7jy)	[Husson, F.; Josse, J.; Le, S.; Mazet, J. FactoMineR: Multivariate Exploratory Data Analysis and Data Mining. **2024**, doi:10.32614/CRAN.package.FactoMineR. ](https://www.zotero.org/google-docs/?WXr7jy)

[40. ](https://www.zotero.org/google-docs/?WXr7jy)	[Kassambara, A.; Mundt, F. Factoextra: Extract and Visualize the Results of Multivariate Data Analyses. **2020**, doi:10.32614/CRAN.package.factoextra. ](https://www.zotero.org/google-docs/?WXr7jy)

[41. ](https://www.zotero.org/google-docs/?WXr7jy)	[Oksanen, J.; Simpson, G.L.; Blanchet, F.G.; Kindt, R.; Legendre, P.; Minchin, P.R.; O’Hara, R.B.; Solymos, P.; Stevens, M.H.H.; Szoecs, E.; et al. Vegan: Community Ecology Package. **2025**, doi:10.32614/CRAN.package.vegan. ](https://www.zotero.org/google-docs/?WXr7jy)

[42. ](https://www.zotero.org/google-docs/?WXr7jy)	[Lenth, R.V.; Bolker, B.; Buerkner, P.; Giné-Vázquez, I.; Herve, M.; Jung, M.; Love, J.; Miguez, F.; Piaskowski, J.; Riebl, H.; et al. Emmeans: Estimated Marginal Means, Aka Least-Squares Means. **2024**, doi:10.32614/CRAN.package.emmeans. ](https://www.zotero.org/google-docs/?WXr7jy)

[43. ](https://www.zotero.org/google-docs/?WXr7jy)	[Galili, T.; O’Callaghan, A.; Sidi, J.; Joo, J.; Benjamini, Y. Heatmaply: Interactive Cluster Heat Maps Using “plotly” and “Ggplot2.” **2023**, doi:10.32614/CRAN.package.heatmaply. ](https://www.zotero.org/google-docs/?WXr7jy)

[44. ](https://www.zotero.org/google-docs/?WXr7jy)	[Lozano-Isla, F. Inti: Tools and Statistical Procedures in Plant Science. **2025**, doi:10.32614/CRAN.package.inti. ](https://www.zotero.org/google-docs/?WXr7jy)

[45. ](https://www.zotero.org/google-docs/?WXr7jy)	[Bates, D.; Maechler, M.; Bolker  [aut, B.; cre; Walker, S.; Christensen, R.H.B.; Singmann, H.; Dai, B.; Scheipl, F.; Grothendieck, G.; et al. Lme4: Linear Mixed-Effects Models Using “Eigen” and S4. **2025**, doi:10.32614/CRAN.package.lme4. ](https://www.zotero.org/google-docs/?WXr7jy)

[46. ](https://www.zotero.org/google-docs/?WXr7jy)	[Caycho, E.; La Torre, R.; Orjeda, G. Assembly, Annotation and Analysis of the Chloroplast Genome of the Algarrobo Tree *Neltuma Pallida* (Subfamily: Caesalpinioideae). *BMC Plant Biol* **2023**, *23*, 570, doi:10.1186/s12870-023-04581-5. ](https://www.zotero.org/google-docs/?WXr7jy)

[47. ](https://www.zotero.org/google-docs/?WXr7jy)	[Villagra, P.E.; Boninsegna, J.A.; Alvarez, J.A.; Cony, M.; Cesca, E.; Villalba, R. Dendroecology of *Prosopis Flexuosa* Woodlands in the Monte Desert: Implications for Their Management. *Dendrochronologia* **2005**, *22*, 209–213, doi:10.1016/j.dendro.2005.05.005. ](https://www.zotero.org/google-docs/?WXr7jy)

[48. ](https://www.zotero.org/google-docs/?WXr7jy)	[Yang, J.; Huang, Y.; Jiang, X.; Chen, H.; Liu, M.; Wang, R. Potential Geographical Distribution of the Edangred Plant *Isoetes* under Human Activities Using MaxEnt and GARP. *Global Ecology and Conservation* **2022**, *38*, e02186, doi:10.1016/j.gecco.2022.e02186. ](https://www.zotero.org/google-docs/?WXr7jy)

[49. ](https://www.zotero.org/google-docs/?WXr7jy)	[Jiang, J.; Wang, Y.-P.; Yang, Y.; Yu, M.; Wang, C.; Yan, J. Interactive Effects of Nitrogen and Phosphorus Additions on Plant Growth Vary with Ecosystem Type. *Plant Soil* **2019**, *440*, 523–537, doi:10.1007/s11104-019-04119-5. ](https://www.zotero.org/google-docs/?WXr7jy)

[50. ](https://www.zotero.org/google-docs/?WXr7jy)	[Hoffland, E.; Kuyper, T.W.; Comans, R.N.J.; Creamer, R.E. Eco-Functionality of Organic Matter in Soils. *Plant Soil* **2020**, *455*, 1–22, doi:10.1007/s11104-020-04651-9. ](https://www.zotero.org/google-docs/?WXr7jy)

[51. ](https://www.zotero.org/google-docs/?WXr7jy)	[Neina, D. The Role of Soil pH in Plant Nutrition and Soil Remediation. *Applied and Environmental Soil Science* **2019**, *2019*, 5794869, doi:10.1155/2019/5794869. ](https://www.zotero.org/google-docs/?WXr7jy)

[52. ](https://www.zotero.org/google-docs/?WXr7jy)	[Ni, Y.; Yang, T.; Ma, Y.; Zhang, K.; Soltis, P.S.; Soltis, D.E.; Gilbert, J.A.; Zhao, Y.; Fu, C.; Chu, H. Soil pH Determines Bacterial Distribution and Assembly Processes in Natural Mountain Forests of Eastern China. *Global Ecology and Biogeography* **2021**, *30*, 2164–2177, doi:10.1111/geb.13373. ](https://www.zotero.org/google-docs/?WXr7jy)

[53. ](https://www.zotero.org/google-docs/?WXr7jy)	[Bello, S.K.; Alayafi, A.H.; AL-Solaimani, S.G.; Abo-Elyousr, K.A.M. Mitigating Soil Salinity Stress with Gypsum and Bio-Organic Amendments: A Review. *Agronomy* **2021**, *11*, 1735, doi:10.3390/agronomy11091735. ](https://www.zotero.org/google-docs/?WXr7jy)

[54. ](https://www.zotero.org/google-docs/?WXr7jy)	[Meglioli, P.A.; Alvarez, J.A.; Lana, N.B.; Cony, M.A.; Villagra, P.E. Salt Tolerance of Native Trees Relevant to the Restoration of Degraded Landscapes in the Monte Region, Argentina. *Restoration Ecology* **2025**, *33*, e14246, doi:10.1111/rec.14246. ](https://www.zotero.org/google-docs/?WXr7jy)

[55. ](https://www.zotero.org/google-docs/?WXr7jy)	[Amin, I.; Rasool, S.; Mir, M.A.; Wani, W.; Masoodi, K.Z.; Ahmad, P. Ion Homeostasis for Salinity Tolerance in Plants: A Molecular Approach. *Physiologia Plantarum* **2021**, *171*, 578–594, doi:10.1111/ppl.13185. ](https://www.zotero.org/google-docs/?WXr7jy)

[56. ](https://www.zotero.org/google-docs/?WXr7jy)	[Zhang, M.; Liu, Y.; Han, G.; Zhang, Y.; Wang, B.; Chen, M. Salt Tolerance Mechanisms in Trees: Research Progress. *Trees* **2021**, *35*, 717–730, doi:10.1007/s00468-020-02060-0. ](https://www.zotero.org/google-docs/?WXr7jy)

[57. ](https://www.zotero.org/google-docs/?WXr7jy)	[Sadia, S.; Waheed, M.; Firdous, S.; Arshad, F.; Fonge, B.A.; Al-Andal, A. Ecological Analysis of Plant Community Structure and Soil Effects in Subtropical Forest Ecosystem. *BMC Plant Biol* **2024**, *24*, 1275, doi:10.1186/s12870-024-06012-5. ](https://www.zotero.org/google-docs/?WXr7jy)

[58. ](https://www.zotero.org/google-docs/?WXr7jy)	[Barboza, E.; Bravo, N.; Cotrina-Sanchez, A.; Salazar, W.; Gálvez-Paucar, D.; Gonzales, J.; Saravia, D.; Valqui-Valqui, L.; Cárdenas, G.P.; Ocaña, J.; et al. Modeling the Current and Future Habitat Suitability of *Neltuma Pallida* in the Dry Forest of Northern Peru under Climate Change Scenarios to 2100. *Ecology and Evolution* **2024**, *14*, e70158, doi:10.1002/ece3.70158. ](https://www.zotero.org/google-docs/?WXr7jy)

[59. ](https://www.zotero.org/google-docs/?WXr7jy)	[Baselly-Villanueva, J.R.; Bazán, F.E.M.; Casas, G.G.; Lozano, A.I.L.; Castedo-Dorado, F.; Álvarez-Álvarez, P. Relación de los factores ambientales con la productividad de *Eucalyptus globulus* en los Andes norperuanos. *Bosque* **2024**, *45*, 103–118, doi:10.4067/S0717-92002024000100103. ](https://www.zotero.org/google-docs/?WXr7jy)

[60. ](https://www.zotero.org/google-docs/?WXr7jy)	[Rufasto-Peralta, Y.L.; Baselly-Villanueva, J.R.; Alva-Mendoza, D.M.; Seminario-Cunya, A.; Elera-Gonzales, D.G.; Villena-Velásquez, J.J. Estimación de la calidad de sitio de *Cinchona pubescens* (Rubiaceae), en el bosque montano La Palma, Chota, Perú. *Lilloa* **2023**, 259–279, doi:10.30550/j.lil/1826. ](https://www.zotero.org/google-docs/?WXr7jy)

[61. ](https://www.zotero.org/google-docs/?WXr7jy)	[Sun, W.; Yuan, X.; Liu, Z.-J.; Lan, S.; Tsai, W.; Zou, S.-Q. Multivariate Analysis Reveals Phenotypic Diversity of *Euscaphis Japonica* Population. *PLOS ONE* **2019**, *14*, e0219046, doi:10.1371/journal.pone.0219046. ](https://www.zotero.org/google-docs/?WXr7jy)

[62. ](https://www.zotero.org/google-docs/?WXr7jy)	[Yadav, R.K.; Gautam, S.; Palikhey, E.; Joshi, B.K.; Ghimire, K.H.; Gurung, R.; Adhikari, A.R.; Pudasaini, N.; Dhakal, R. Agro-Morphological Diversity of Nepalese Naked Barley Landraces. *Agriculture & Food Security* **2018**, *7*, 86, doi:10.1186/s40066-018-0238-5. ](https://www.zotero.org/google-docs/?WXr7jy)

[63. ](https://www.zotero.org/google-docs/?WXr7jy)	[Bessega, C.; Cony, M.; Pometti, C. Genetic Zones of *Neltuma Flexuosa*, the Algarrobo Tree from the Monte Desert in Argentina. *Forest Ecology and Management* **2025**, *586*, 122715, doi:10.1016/j.foreco.2025.122715. ](https://www.zotero.org/google-docs/?WXr7jy)

[64. ](https://www.zotero.org/google-docs/?WXr7jy)	[Vega, M.V.; Saidman, B.O.; Vilardi, J.C.; Vega, M.V.; Saidman, B.O.; Vilardi, J.C. Spatial Structure of Phenotypic Traits in Seven Provenances of *Neltuma Alba* (Fabaceae). *Boletín de la Sociedad Argentina de Botánica* **2023**, *58*, 6–6, doi:10.31055/1851.2372.v58.n4.39224. ](https://www.zotero.org/google-docs/?WXr7jy)

[65. ](https://www.zotero.org/google-docs/?WXr7jy)	[Esparza-Orozco, A.; Carranza-Becerra, L.; Delgadillo-Ruiz, L.; Bollaín y Goytia, J.J.; Gaytán-Saldaña, N.A.; Mandujano-García, C.D.; Delgadillo-Ruiz, E.; Michel-López, C.Y.; Huerta-García, J.; Valladares-Carranza, B.; et al. Environmental Heterogeneity Drives Secondary Metabolite Diversity from Mesquite Pods in Semiarid Regions. *Ecologies* **2025**, *6*, 19, doi:10.3390/ecologies6010019. ](https://www.zotero.org/google-docs/?WXr7jy)

[66. ](https://www.zotero.org/google-docs/?WXr7jy)	[Vidaković, A.; Liber, Z.; Šatović, Z.; Idžojtić, M.; Volenec, I.; Zegnal, I.; Pintar, V.; Radunić, M.; Poljak, I. Phenotypic Diversity of Almond-Leaved Pear (*Pyrus Spinosa* Forssk.) along Eastern Adriatic Coast. *Forests* **2021**, *12*, 1630, doi:10.3390/f12121630. ](https://www.zotero.org/google-docs/?WXr7jy)

[67. ](https://www.zotero.org/google-docs/?WXr7jy)	[Wang, C.; Gong, H.; Feng, M.; Tian, C. Phenotypic Variation in Leaf, Fruit and Seed Traits in Natural Populations of *Eucommia Ulmoides*, a Relict Chinese Endemic Tree. *Forests* **2023**, *14*, 462, doi:10.3390/f14030462. ](https://www.zotero.org/google-docs/?WXr7jy)

[68. ](https://www.zotero.org/google-docs/?WXr7jy)	[Torres-Sánchez, E.; Acosta, J.J.; Hodge, G.R.; Prada, E.; Menéndez-Gutiérrez, M.; Díaz, R. Volume-Based Selection in Pinus Pinaster Aiton Breeding: Evaluating Resistance to *Bursaphelenchus Xylophilus* (Steiner & Buhrer) Nickle and Wood Properties. *Annals of Forest Science* **2024**, *81*, 46, doi:10.1186/s13595-024-01266-3. ](https://www.zotero.org/google-docs/?WXr7jy)

[69. ](https://www.zotero.org/google-docs/?WXr7jy)	[Zhang, Q.; Chen, S.; Qu, G.; Yang, Y.; Lu, Z.; Wang, J.; Tigabu, M.; Liu, J.; Xu, L.; Wang, F. Provenance and Family Variations in Early Growth of Manchurian Walnut (*Juglans Mandshurica* Maxim.) and Selection of Superior Families. *PLoS One* **2024**, *19*, e0298918, doi:10.1371/journal.pone.0298918. ](https://www.zotero.org/google-docs/?WXr7jy)

[70. ](https://www.zotero.org/google-docs/?WXr7jy)	[Vallejos, J.; Badilla, Y.; Picado, F.; Murillo, O. Metodología Para La Selección e Incorporación de Árboles plus En Programas de Mejoramiento Genético Forestal. *Agronomía Costarricense* **2010**, *34*, 105–119. ](https://www.zotero.org/google-docs/?WXr7jy)

[71. ](https://www.zotero.org/google-docs/?WXr7jy)	[Duarte, D.; Jurcic, E.J.; Dutour, J.; Villalba, P.V.; Centurión, C.; Grattapaglia, D.; Cappa, E.P. Genomic Selection in Forest Trees Comes to Life: Unraveling Its Potential in an Advanced Four-Generation *Eucalyptus Grandis* Population. *Front. Plant Sci.* **2024**, *15*, doi:10.3389/fpls.2024.1462285. ](https://www.zotero.org/google-docs/?WXr7jy)